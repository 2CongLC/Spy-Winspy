WinSpy++
--------

WinSpy++ is a programmer's utility for inspecting and modifying window properties of any Windows program.

Building WinSpy
---------------

WinSpy requires Visual Studio 2010, and supports win32 and win64 builds. Use the IDE to build winspy, or 
the build/build.bat commandline script to build and package a zipfile for distribution

