#define BUILD_MAJ 1
#define BUILD_MIN 0
#define BUILD_PAT 0
#define BUILD_NUM 0

