#ifndef CAPTURE_WINDOW_INCLUDED
#define CAPTURE_WINDOW_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

BOOL CaptureWindow(HWND hwndOwner, HWND hwnd);

#ifdef __cplusplus
}
#endif

#endif