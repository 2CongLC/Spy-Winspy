#ifndef WINDOWFROMPOINT_INCLUDED
#define WINDOWFROMPOINT_INCLUDED

#ifdef __cplusplus
extern "C" {
#endif

HWND WindowFromPointEx(POINT pt, BOOL fShowHidden);

#ifdef __cplusplus
}
#endif

#endif